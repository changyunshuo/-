package com.example.filedemo3

data class Item(
    val id: Int,
    val imageUrl: String,
    val title: String,
    val description: String,
    val detailedDescription: String
)