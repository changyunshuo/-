package com.example.filedemo3

object ItemRepository {
    val items = listOf(
        Item(1, "https://pics0.baidu.com/feed/d01373f082025aaf5db800829430966a014f1ad8.jpeg@f_auto?token=1d6e496183fba324776843c0fc6bfeb0", "Jay Chou", "Famous singer", "Jay Chou, born on January 18, 1979 in New Taipei City, Taiwan, has ancestral roots in Yongchun County, Fujian Province. He is a male Chinese pop singer, musician, actor, director, and screenwriter. He graduated from Tamkang High School."),
        Item(2, "https://pics3.baidu.com/feed/42166d224f4a20a49ee97ac2fc641b2f730ed080.jpeg@f_auto?token=f90a79ed41cf448df44d41fcac71ea84", "Chun Wu", "Famous singer", "Chun Wu, formerly known as Wu Jizun, was born on October 10, 1979 in Brunei. He is a Chinese language actor and pop singer, and graduated from the Royal Melbourne Institute of Technology in Australia.\n" +
                "In 2005, he joined the \"Fahrenheit\" group and announced his official debut."),
        // ... 添加至少7个元素
    )

    fun getItemById(id: Int) = items.find { it.id == id }
}